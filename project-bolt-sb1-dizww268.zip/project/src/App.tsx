import React from 'react';
import { WeatherDashboard } from './components/WeatherDashboard';

function App() {
  return (
    <WeatherDashboard />
  );
}

export default App;